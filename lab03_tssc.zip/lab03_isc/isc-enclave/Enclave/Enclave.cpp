#include "string.h"
#include "Enclave_t.h"
#include<stdio.h>
/* TODO: Add SGX trusted libraries headers if needed */ 
#include "sgx_trts.h"
#include "sgx_tseal.h"

#define SECRET_FILE "enclave_secret"

void printf(const char *fmt, ...)
{
    char buf[BUFSIZ] = {'\0'};
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, BUFSIZ, fmt, ap);
    va_end(ap);
    ocall_print(buf);
}

int get_sum(int a, int b) {
	ocall_print("Adding numbers inside enclave...");
	return a + b;
}

/* TODO 1: Generate a random unsigned int using a trusted library */
unsigned int generate_random_number() {
	// Add code here
    	unsigned int buf;
	sgx_read_rand((unsigned char*)&buf, sizeof(unsigned int));
	return buf;
}

/* TODO 3: Sealing function */
void seal_secret() {
	// Add code here to seal "SGX_RULLZ".
	// TODO 4: Generate random string to seal.
	char buf[10] = {"SGX_RULLZ"};
	sgx_sealed_data_t *p_sealed_data = (sgx_sealed_data_t *)malloc(sizeof(sgx_sealed_data_t));

	sgx_seal_data(0, NULL, 10, (const unsigned char *)buf, sgx_calc_sealed_data_size(0, 9), p_sealed_data);
}

/* TODO 5: Unsealing function */
void unseal_secret(){
	// Add code here
	//uint32_t p_decrypted_text_length;
	//char buf[256];
	//sgx_unseal_data( (const unsigned char *)SECRET_FILE, buf, 0, &p_decrypted_text_length);
}

